// backend/server.js
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const User = require('./Models/User'); // <-- model
const authRoutes = require('./Routes/Auth'); // adjust path if needed


const app = express();
app.use(cors());
app.use(express.json()); // for parsing JSON

// ✅ Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/formDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ MongoDB Connected'))
.catch((err) => console.error('❌ MongoDB Error:', err));

// ✅ Create the route: /api/auth/register
app.post('/api/auth/register', async (req, res) => {
  try {
    const newUser = new User(req.body);
    await newUser.save();
    res.status(200).json({ message: 'User registered successfully!' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to register user' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // In real app, use hashed passwords. For now, simple check:
    if (user.password !== password) {
      return res.status(401).json({ message: 'Incorrect password' });
    }

    res.status(200).json({ message: 'Login successful', user });
  } catch (err) {
    res.status(500).json({ error: 'Login error' });
  }
});

app.use('/api', authRoutes);

app.post('/api/place-order', async (req, res) => {
  try {
    const newOrder = new Order(req.body); // ✅ use Order model
    await newOrder.save();
    res.status(201).json({ message: 'Order placed successfully!' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to place order' });
  }
});


// ✅ Start the server
app.listen(5000, () => {
  console.log('🚀 Server is running on http://localhost:5000');
});
