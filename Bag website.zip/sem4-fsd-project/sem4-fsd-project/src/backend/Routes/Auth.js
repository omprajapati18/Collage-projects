const express = require('express');
const router = express.Router();
const User = require('../Models/User');
const Order = require('../Models/Order'); // ✅ this must be added

// Register
router.post('/register', async (req, res) => {
  const { username, password, email, phone } = req.body;

  if (!username || !password || !email) {
    return res.status(400).json({ error: 'All fields are required.' });
  }

  try {
    const newUser = new User({ username, password, email, phone });
    await newUser.save();
    res.status(200).json({ message: 'User registered successfully!' });
  } catch (err) {
    res.status(500).json({ error: 'Error registering user.' });
  }
});

// Login
router.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await User.findOne({ username, password });

    if (user) {
      res.status(200).json({ message: 'Login successful' });
    } else {
      res.status(400).json({ error: 'Invalid credentials' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Error logging in.' });
  }
});

router.post('/place-order', async (req, res) => {
  try {
    const newOrder = new Order(req.body);
    await newOrder.save();
    res.status(201).json({ message: 'Order placed successfully!' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to place order' });
  }
});

module.exports = router;
