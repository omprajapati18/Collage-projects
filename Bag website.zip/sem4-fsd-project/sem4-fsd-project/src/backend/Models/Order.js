const mongoose = require('mongoose');


const productSchema = new mongoose.Schema({
  name: String,
  price: Number,
  image: String,
  quantity: Number  // optional
});


const orderSchema = new mongoose.Schema({
  name: String,
  address: String,
  city: String,
  phone: String,
  email: String,
  products: [productSchema],
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Order', orderSchema);
