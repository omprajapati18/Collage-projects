import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Products from './components/Products';
import CartBill from './components/CartBill';
import CheckOut from './components/CheckOut'; // ✅ Make sure this exists
import Footer from './components/Footer';
import { useState } from 'react';

export default function Web() {
  const [cart, setCart] = useState([]);
  const [showCart, setShowCart] = useState(false);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  const removeFromCart = (index) => {
    const updatedCart = cart.filter((_, i) => i !== index);
    setCart(updatedCart);
  };

  const handleCartClick = () => {
    setShowCart(!showCart);
  };

  return (
    <>
      <Navbar onCartClick={handleCartClick} />
      <Routes>
        <Route
          path="/"
          element={
            <>
              <Products addToCart={addToCart} />
              <Footer />
              {showCart && (
                <CartBill
                  cart={cart}
                  removeFromCart={removeFromCart}
                  onClose={() => setShowCart(false)}
                />
              )}
            </>
          }
        />

        <Route
          path="/checkout"
          element={<CheckOut cart={cart} />}
        />
      </Routes>
    </>
  );
}
