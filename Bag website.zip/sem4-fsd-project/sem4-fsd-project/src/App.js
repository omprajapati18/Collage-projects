// src/App.js
import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Web from './Web';
import LoginForm from './components/LoginForm';
import RegistrationForm from './components/RegistrationForm';
import CheckOut from './components/CheckOut';
import OrderSuccess from './components/OrderSuccess';

function App() {
  const [cart, setCart] = useState([]);

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Web cart={cart} setCart={setCart} />} />
        <Route path="/login" element={<LoginForm />} />
        <Route path="/register" element={<RegistrationForm />} />
        <Route path="/CheckOut" element={<CheckOut cart={cart} />} />
         <Route path="/order-success" element={<OrderSuccess />} />
      </Routes>
    </Router>
  );
}

export default App;
