import React from 'react';
import '../Style/Footer.css';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-section" id='footer'>
        <h3>CATEGORIES</h3>
        <ul>
          <li>Backpack</li>
          <li>Duffle</li>
          <li>Luggage</li>
        </ul>
      </div>

      <div className="footer-section">
        <h3>OTHER LINKS</h3>
        <ul>
          <li>About Us</li>
          <li>Store Locator</li>
          <li>Contact Us</li>
          <li>FAQ</li>
        </ul>
      </div>

      <div className="footer-section">
        <h3>POLICIES</h3>
        <ul>
          <li>Privacy Policy</li>
          <li>Cancellation, Return & Refund Policy</li>
          <li>Return & Exchange</li>
          <li>Terms of offers/promotions</li>
          <li>Warranty Terms and Conditions</li>
        </ul>
      </div>

      <div className="footer-section">
        <h3>SUPPORT</h3>
        <ul>
          <li>Enquiry</li>
          <li>Register Product</li>
          <li>Product Utility</li>
        </ul>
      </div>

      <div className="footer-section address">
        <h3>ADDRESS</h3>
        <p>VIP INDUSTRIES LTD</p>
        <p>DGP House, 5th Floor, 88C,<br/>Old Prabhadevi Road, Mumbai - 400025</p>
        <p>Phone: 022-41724444</p>
        <p>Mail: talk2me@skybags.com</p>
        <p>(Monday To Sunday, 8.00 AM To 8 PM)</p>
      </div>

        <div className="social-icons">
    <a href="#"><i className="fab fa-facebook-f"></i></a>
    <a href="#"><i className="fab fa-instagram"></i></a>
    <a href="#"><i className="fab fa-youtube"></i></a>
    <a href="#"><i className="fab fa-x-twitter"></i></a>
    </div>

    </footer>
  );
}
