  import React, { useState } from 'react';
  import {useNavigate } from 'react-router-dom';
  
  import '../Style/Registration.css';

  export default function RegisterForm({ onClose }) {
    const navigate = useNavigate();
    const [fullName, setFullName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState('');

   const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\[\]{}|;:',.<>/?]).{8,}$/;


    function validateForm() {
      if (fullName.trim() === '') {
        setErrorMessage('Full name is required');
        return false;
      }
      if (!emailRegex.test(email)) {
        setErrorMessage('Enter a valid email address');
        return false;
      }
      if (!passwordRegex.test(password)) {
        setErrorMessage('Password must be at least 6 characters and contain letters and numbers');
        return false;
      }
      setErrorMessage('');
      return true;
    }

    function handleSubmit(e) {
    e.preventDefault();
    if (validateForm()) {
      const userData = {
        username: fullName,
        email: email,
        password: password,
      };

      fetch('http://localhost:5000/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.message) {
            alert('Registration successful!');
            navigate('/login'); // or redirect to login
          } else if (data.error) {
            setErrorMessage(data.error);
          }
        })
        .catch((err) => {
          setErrorMessage('Error registering user.');
          console.error(err);
        });
    }
  }


    const handleclose = () => {
    navigate('/'); // Redirects to the homepage or navbar
  };


    return (
      <div className="form-container">
        <h2>Create Account</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Full Name"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
          />
          <input
            type="text"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
          <button type="submit">Register</button>
          <button type="button" onClick={handleclose}>Close</button>
        </form>
      </div>
    );
  }
