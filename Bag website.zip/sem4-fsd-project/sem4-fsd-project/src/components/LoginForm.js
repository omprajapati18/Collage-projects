import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import '../Style/Login.css';

export default function LoginForm({ onClose }) {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/;

  // If already logged in, redirect to home
  useEffect(() => {
    if (localStorage.getItem('isLoggedIn') === 'true') {
      navigate('/');
    }
  }, [navigate]);

  function validateForm() {
    if (!emailRegex.test(email)) {
      setErrorMessage('Enter a valid email address');
      return false;
    }
    if (!passwordRegex.test(password)) {
      setErrorMessage('Password must be at least 6 characters and contain letters and numbers');
      return false;
    }
    setErrorMessage('');
    return true;
  }

  function handleSubmit(e) {
    e.preventDefault();

    if (validateForm()) {
      // Send login data to backend
      fetch('http://localhost:5000/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username: email, password }) // using email as username
      })
        .then(res => res.json())
        .then(data => {
          console.log('Response from server:', data);

          if (data.message === 'Login successful') {
            // Save login state to localStorage
            localStorage.setItem('isLoggedIn', 'true');
            localStorage.setItem('userEmail', email);

            console.log('Logged in!');
            navigate('/'); // Redirect to homepage or dashboard
          } else {
            setErrorMessage(data.error || 'Login failed');
          }
        })
        .catch(error => {
          console.error('Error:', error);
          setErrorMessage('Login error. Please try again later.');
        });
    }
  }

  const handleClose = () => {
    navigate('/'); // Redirect to home
  };

  return (
    <div className="form-container">
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}

        <button type="submit">Login</button>

        <p>
          Don’t have an account?{' '}
          <Link to="/register" className="link">Create Account</Link>
        </p>

        <button type="button" onClick={handleClose}>Close</button>
      </form>
    </div>
  );
}
