// src/components/OrderSuccess.js ✅

import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import '../Style/OrderSuccess.css'; // use a separate CSS file

export default function OrderSuccess() {
  const location = useLocation();
  const navigate = useNavigate();
  const { order } = location.state || {};

  if (!order) {
    return (
      <div className="order-success">
        <h2>❌ No order details found.</h2>
        <button onClick={() => navigate('/')}>Go Back to Home</button>
      </div>
    );
  }

  const total = order.products?.reduce((sum, item) => sum + item.price, 0) || 0;

  return (
    <div className="order-success">
      <h2>✅ Order Placed Successfully!</h2>
      <h3>Thank you, {order.name} 🎉</h3>
      <p>We’ve received your order and will ship it to:</p>
      <p>{order.address}, {order.city}</p>
      <p>📞 {order.phone} | 📧 {order.email}</p>

      <h3>🧾 Bill Summary:</h3>
      <ul>
        {order.products?.map((item, index) => (
          <li key={index}>{item.name} - ₹{item.price}</li>
        ))}
      </ul>
      <p><strong>Total: ₹{total}</strong></p>

      <button onClick={() => navigate('/')}>Continue Shopping</button>
    </div>
  );
}
