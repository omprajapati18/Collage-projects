import React from 'react';
import '../Style/Products.css';

export default function Products({ addToCart }) {
  const products = [
    { id: 1, name: 'Gamer Raze', price: 1499, image: '/bag1.png' },
    { id: 2, name: 'Neo Trek', price: 1299, image: '/bag2.png' },
    { id: 3, name: 'Maze Mint', price: 1399, image: '/bag3.png' },
    { id: 4, name: 'Signature Black', price: 1599, image: '/bag4.png' },
  ];

  const luggage = [
    { id: 5, name: 'Voyager Pro', price: 1999, image: '/luggage1.png' },
    { id: 6, name: 'Travel Ace', price: 1799, image: '/luggage2.png' },
    { id: 7, name: 'Travel Ace', price: 1799, image: '/luggage3.png' },
    { id: 8, name: 'Travel Ace', price: 1799, image: '/luggage4.png' },
  ];

  return (
    <div >
      <h2 id="backpacks" style={{ textAlign: 'center' }}>👜 Shop Backpacks</h2>
      <div className="simple-slider">
        {products.map((product) => (
          <div className="product-card" key={product.id}>
            <img src={product.image} alt={product.name} />
            <p className="product-name">{product.name}</p>
            <p className="product-price">₹{product.price}</p>
            <button onClick={() => addToCart(product)}>Add to Cart</button>
          </div>
        ))}
      </div>


      { /* Luggage Section */ }
      <h2 id="luggage" style={{ textAlign: 'center' }}>🧳 Shop Luggage</h2>
      <div className="simple-slider">
        {luggage.map((product) => (
          <div className="product-card" key={product.id}>
            <img src={product.image} alt={product.name} />
            <p className="product-name">{product.name}</p>
            <p className="product-price">₹{product.price}</p>
            <button onClick={() => addToCart(product)}>Add to Cart</button>
          </div>
        ))}
      </div>
    </div>
    



  );
}
