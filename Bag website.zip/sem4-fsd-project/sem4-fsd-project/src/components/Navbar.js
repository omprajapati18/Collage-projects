// src/components/Navbar.js
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaUser,  FaShoppingCart } from 'react-icons/fa';
import '../Style/Navbar.css';

export default function Navbar({ onCartClick }) {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userEmail, setUserEmail] = useState('');

  useEffect(() => {
    const loggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const email = localStorage.getItem('userEmail');
    setIsLoggedIn(loggedIn);
    setUserEmail(email || '');
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userEmail');
    setIsLoggedIn(false);
    setUserEmail('');
    navigate('/');
  };

  const scrollToSection = (id) => {
    const section = document.getElementById(id);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div>
      <div className="navbar">
        <div className="logo-section">
          <img src="/skybaglogo.png" alt="Skybags Logo" className="logo" />
        </div>

        <div className="nav-links">
          <a href="#" onClick={() => scrollToSection('luggage')}>Luggage</a>
          <a href="#" onClick={() => scrollToSection('backpacks')}>Backpack</a>
          <a href="#" onClick={() => scrollToSection('footer')}>Contact Us</a>
        </div>

        <div className="icons">
          <div className="user-section">
            <FaUser
              className="icon"
              onClick={() => {
                if (isLoggedIn) {
                  alert(`You are logged in as: ${userEmail}`);
                } else {
                  navigate('/login');
                }
              }}
            />
            {isLoggedIn && (
              <>
                <span className="user-email">{userEmail}</span>
                <button onClick={handleLogout} className="logout-btn">Logout</button>
              </>
            )}
          </div>
          
          <FaShoppingCart className="icon" onClick={onCartClick} />
        </div>
      </div>

      <div className="banner-container">
        <img src="/backtoschool.png" alt="Back to School" className="banner-img" />
      </div>
    </div>
  );
}
