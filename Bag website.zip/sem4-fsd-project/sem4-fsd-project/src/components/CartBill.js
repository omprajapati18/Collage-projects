// src/components/CartBill.js
import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../Style/CartBill.css';

export default function CartBill({ cart = [], removeFromCart, onClose }) {
  const navigate = useNavigate();
  const totalAmount = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <div className="cart-overlay">
      <div className="cart-sidebar">
        <div className="cart-header">
          <h2>🛒 Cart</h2>
          <button className="close-btn" onClick={onClose}>×</button>
        </div>
        <div className="cart-items">
          {cart.length === 0 ? (
            <p>Your cart is empty.</p>
          ) : (
            <>
              <ul>
                {cart.map((item, index) => (
                  <li key={index} className="cart-item">
                    <img src={item.image} alt={item.name} />
                    <div className="item-info">
                      <span>{item.name}</span>
                      <span>₹{item.price}</span>
                    </div>
                    <button onClick={() => removeFromCart(index)}>Remove</button>
                  </li>
                ))}
              </ul>
              <hr />
              <div className="subtotal">
                <strong>Subtotal: ₹{totalAmount}</strong>
              </div>
              <button className="checkout-btn" onClick={() => navigate('/checkout',{ state: { cart } })}>
                Proceed to Checkout
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
