// src/components/Search.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Search() {
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  const handleSearch = () => {
    const trimmed = searchTerm.trim().toLowerCase();
    if (trimmed !== '') {
      localStorage.setItem('search', trimmed);
      navigate('/products');
    }
  };

  return (
    <div style={{ display: 'flex', gap: '6px' }}>
      <input
        type="text"
        placeholder="Search bags..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)} 
      />
      <button onClick={handleSearch}>Search</button>
    </div>
  );
}
