// src/components/CheckoutForm.js
import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

import '../Style/CheckoutForm.css';

export default function Checkout() {
  const navigate=useNavigate()
  const location = useLocation();
  const { cart } = location.state || {};
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    city: '',
    phone: '',
    email: ''
  });

  const handleChange = (e) => {
    setFormData({ 
      ...formData, 
      [e.target.name]: e.target.value 
    });
  };

  const handleSubmit = async (e) => {
  e.preventDefault();
  const orderData = {
      ...formData,
      products: cart   // ✅ cart data passed from Web.js
    };

  try {
    const res = await fetch('http://localhost:5000/api/place-order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData)
    });

    const data = await res.json();
    if (res.ok) {
      alert(data.message);
      setFormData({
        name: '',
        address: '',
        city: '',
        phone: '',
        email: ''
      });
      navigate('/order-success', { state: { order: orderData } });
    } else {
      alert('Order failed: ' + data.error);
    }
  } catch (error) {
    alert('Error placing order');
    console.error(error);
  }

  
};


  return (
    <div className="checkout-form">
      <h2>🧾 Checkout & Place Order</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="name" placeholder="Full Name" required onChange={handleChange} />
        <input type="text" name="address" placeholder="Shipping Address" required onChange={handleChange} />
        <input type="text" name="city" placeholder="City" required onChange={handleChange} />
        <input type="tel" name="phone" placeholder="Phone Number" required onChange={handleChange} />
        <input type="email" name="email" placeholder="Email Address" required onChange={handleChange} />
        <button type="submit">Place Order</button>
      </form>
    </div>
  );
}
